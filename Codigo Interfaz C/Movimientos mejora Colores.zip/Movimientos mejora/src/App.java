import vista.MenuPrincipal;
public class App {
    public static void main(String[] args) {
        MenuPrincipal mp = new MenuPrincipal();
            mp.menu();
    }
}