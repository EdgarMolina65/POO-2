package controlador;
import javax.swing.JOptionPane;

public class Consola {
    public static double pedirTiempo() {
    double aux = 0;
    aux = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el tiempo en segundos (debe ser positivo):"));
    while (aux < 0) {
        aux = Double.parseDouble(JOptionPane.showInputDialog("Intente nuevamente, debe ser un numero positivo (no usar letras o caracteres)"));
    }
    return aux;
    }
    public double recibirNumero(String mensaje){
        double result = 0;
        boolean error = false;
            try{
                result = Double.parseDouble(JOptionPane.showInputDialog(mensaje));
            }catch(Exception e){
                error = true;
            }            
            while(result <0 || error == true){
                try{
                    error = false;
                    result = Double.parseDouble(JOptionPane.showInputDialog("Intente nuevamente, debe ser un numero positivo (no usar letras o caracteres)"+mensaje));
                }catch(Exception e){
                    error = true;
                    JOptionPane.showMessageDialog(null, "Error..."+e+ "Debe ser un numero (no usar letras o caracteres)");           
                }
            }        
        return result;
    }
    public void mostrarMensaje(String mensaje){
        JOptionPane.showMessageDialog(null, mensaje);
    }
}