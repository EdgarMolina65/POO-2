package vista;

import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JOptionPane;
import modelo.*;

public class MenuPrincipal {
    public void menu (){
        //Colores
         // Cambiar el color de fondo
        UIManager.put("OptionPane.background", Color.cyan);
        UIManager.put("Panel.background", Color.WHITE); // También cambiar el fondo del panel
        UIManager.put("Button.background", Color.GREEN); // También cambiar el fondo de los botones
        UIManager.put("TextField.background", Color.WHITE); // También cambiar el fondo de los campos de texto
        
        String[] opciones = {"MRU", "MRUA", "Caída Libre", "Movimiento 2D", "Salir"};
        Movimiento obj;
        while (true) {
            int opcion = JOptionPane.showOptionDialog(null,
                    "Selecciona el tipo de movimiento:",
                    "Calculadora Física",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, //Icono Programa
                    opciones,
                    opciones[0]);

            if (opcion == -1 || opcion == 4) break;

            switch (opcion) {
                case 0:
                    obj = new MRU();
                    obj.mostrarOpciones();
                break;
                case 1:
                    obj = new MRUA();
                    obj.mostrarOpciones();
                break;
                case 2:
                    obj = new CaidaLibre();
                    obj.mostrarOpciones();
                break;
                case 3:
                    obj = new Movimiento2D();
                    obj.mostrarOpciones();
                break;
                //case 1 -> movimiento = new MRUA();
                //case 2 -> movimiento = new CaidaLibre();
                //case 3 -> movimiento = new Movimiento2D();
                default:
                    JOptionPane.showMessageDialog(null,"Opción inválida");
                    break;
            }

            //movimiento.calcular();
        }
    }
}
