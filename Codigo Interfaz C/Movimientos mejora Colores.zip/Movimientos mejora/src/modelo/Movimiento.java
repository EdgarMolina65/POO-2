package modelo;
public abstract class Movimiento  {
    
    private double v;
    private double t;
    private double a;
    private double d;

    public Movimiento() {
    }

    public abstract void mostrarOpciones();
    
    public double getV() {
        return v;
    }

    public void setV(double v) {
        this.v = v;
    }

    public double getT() {
        return t;
    }

    public void setT(double t) {
        this.t = t;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getD() {
        return d;
    }

    public void setD(double d) {
        this.d = d;
    }
}