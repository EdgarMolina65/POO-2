package modelo;
import javax.swing.JOptionPane;
import controlador.*;

public class MRU extends Movimiento {
    Consola objConsola = new Consola();

    @Override
    public void mostrarOpciones() {
        String[] opciones = {"Calcular Distancia (m)", "Calcular Velocidad (m/s)", "Calcular Tiempo (s)"};
        int opcion = JOptionPane.showOptionDialog(null, "¿Qué deseas calcular?", "MRU", 
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (opcion) {
            case 0 -> calcularDistancia();
            case 1 -> calcularVelocidad();
            case 2 -> calcularTiempo();
        }
    }
   
    private void calcularDistancia() {
        setV(objConsola.recibirNumero("Ingrese la velocidad (m/s): "));
        setT(objConsola.recibirNumero("Ingrese el tiempo (s): "));
        setD(getV()*getT());
        String mensaje = "La distancia es: " + getD() + "m.";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularVelocidad() {
        setD(objConsola.recibirNumero("Ingrese la distancia (m): "));
        setT(objConsola.recibirNumero("Ingrese el tiempo (s): "));
        setV(getD()*getT());
        String mensaje = "La velocidad es: " + getV() + "m/s";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularTiempo() {
        setD(objConsola.recibirNumero("Ingrese la distancia (m): "));
        setV(objConsola.recibirNumero("Ingrese la velocidad (m/s): "));
        setT(getD()*getV());
        String mensaje = "El tiempo es: " + getT() + "s";
        objConsola.mostrarMensaje(mensaje);
    }
}