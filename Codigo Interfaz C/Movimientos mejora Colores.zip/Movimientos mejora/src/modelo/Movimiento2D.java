package modelo;
import javax.swing.JOptionPane;
import controlador.*;

public class Movimiento2D extends Movimiento {

    private double alc;
    private double ang;
    Consola objConsola = new Consola();


    @Override
    public void mostrarOpciones() {
        String[] opciones = {"Alcance horizontal (m)", "Altura máxima (m)", "Tiempo total (s)"};
        int opcion = JOptionPane.showOptionDialog(null, "¿Qué deseas calcular?", "Movimiento 2D",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (opcion) {
            case 0 -> calcularAlcance();
            case 1 -> calcularAlturaMax();
            case 2 -> calcularTiempoTotal();
        }
    }
    
    private void calcularAlcance() {
        setV(objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): "));
        ang = Math.toRadians(objConsola.recibirNumero("Ingrese el Angulo de lanzamiento (grados):"));
        setA(9.8);
        alc = (getV() * getV() * Math.sin(2 * ang)) / getA();
        String mensaje = "El Alcance horizontal es: " + alc + "m";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularAlturaMax() {
        setV(objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): "));
        ang = Math.toRadians(objConsola.recibirNumero("Ingrese el Angulo de lanzamiento (grados):"));
        setA(9.8);
        setD(getV() * getV() * Math.pow (Math.sin(ang), 2) / (2 * getA()));
        String mensaje = "La Altura máxima es: " + getD() + "m";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularTiempoTotal() {
        setV(objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): "));
        ang = Math.toRadians(objConsola.recibirNumero("Ingrese el Angulo de lanzamiento (grados):"));
        setA(9.8);
        setT((2 * getV() * Math.sin(ang)) / getA());
        String mensaje = "El Tiempo total de vuelo es: " + getT() + "s";
        objConsola.mostrarMensaje(mensaje);
    }
}