package modelo;
import javax.swing.JOptionPane;

import controlador.Consola;

public class CaidaLibre extends Movimiento {
    Consola objConsola = new Consola();
   

    @Override
    public void mostrarOpciones() {
        String[] opciones = {
            "Altura (m)",
            "Tiempo (s)",
            "Velocidad final (m/s)"
        };
        int opcion = JOptionPane.showOptionDialog(null, "¿Qué deseas calcular?", "Caída Libre",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (opcion) {
            case 0 -> calcularAltura();
            case 1 -> calcularTiempo();
            case 2 -> calcularVelocidadFinal();
        }
    }

    private void calcularAltura() {
        setT(objConsola.recibirNumero("Ingrese el Tiempo (s):"));
        setA(9.8);
        setD(0.5 * getA() * getT()*getT());
        String mensaje = "La Altura es: " + getD() + "m";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularTiempo() {
        setD(objConsola.recibirNumero("Ingrese la Altura (m):"));
        setA(9.8);
        setT(Math.sqrt(2 * getD() / getA()));
        String mensaje = "El Tiempo es: " + getT() + "s";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularVelocidadFinal() {
        setT(objConsola.recibirNumero("Ingrese el Tiempo de caída (s):"));
        setA(9.8);
        setV(getA() * getT());
        String mensaje = "La Velocidad final es: " + getV() + "m/s";
        objConsola.mostrarMensaje(mensaje);
    }
}