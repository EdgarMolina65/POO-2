package modelo;
import javax.swing.JOptionPane;

import controlador.Consola;

public class MRUA extends Movimiento {

    private double v0;
    private double vf;
    Consola objConsola = new Consola();


    @Override
    public void mostrarOpciones() {

        String[] opciones = {
            "Velocidad Final (m/s)", 
            "Distancia (m)", 
            "Aceleración (m/s²)", 
            "Tiempo (s)"
        };
        int opcion = JOptionPane.showOptionDialog(null, "¿Qué deseas calcular?", "MRUA",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        switch (opcion) {
            case 0 -> calcularVelocidadFinal();
            case 1 -> calcularDistancia();
            case 2 -> calcularAceleracion();
            case 3 -> calcularTiempo();
        }
    }

    private void calcularVelocidadFinal() {
        v0 = objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): ");
        setA(objConsola.recibirNumero("Ingrese la aceleracion (m/s²): "));
        setT(objConsola.recibirNumero("Ingrese el Tiempo (s):"));
        vf = v0 + (getA()*getT());
        String mensaje = "La velocidad final es: " + vf + "m/s";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularDistancia() {
        v0 = objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): ");
        setT(objConsola.recibirNumero("Ingrese el Tiempo (s):"));
        setA(objConsola.recibirNumero("Ingrese la aceleracion (m/s²): "));
        setD((v0 * getT() ) + (0.5 * (getA() * getT() * getT())));
        String mensaje = "La distancia es: " + getD() + "m.";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularAceleracion() {
        vf = objConsola.recibirNumero("Ingrese la velocidad final (m/s): ");
        v0 = objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): ");
        setT(objConsola.recibirNumero("Ingrese el Tiempo (s):"));
        setA((vf - v0) / getT());
        String mensaje = "La Aceleración es: " + getA() + "m/s²";
        objConsola.mostrarMensaje(mensaje);
    }

    private void calcularTiempo() {
        vf = objConsola.recibirNumero("Ingrese la velocidad final (m/s): ");
        v0 = objConsola.recibirNumero("Ingrese la velocidad inicial (m/s): ");
        setA(objConsola.recibirNumero("Ingrese la Aceleración (m/s²):"));
        setT((vf - v0) / getA());
        String mensaje = "El Tiempo es: " + getT() + "s";
        objConsola.mostrarMensaje(mensaje);
    }
}